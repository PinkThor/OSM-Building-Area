# OSM Building Area

Shows an estimated building footprint area in the OpenStreetMap object sidebar.

## Install

1. Unzip the folder.
2. Open `chrome://extensions` (Chrome) or `edge://extensions` (Edge).
3. Turn on **Developer mode**.
4. Click **Load unpacked** and pick the unzipped `osm-building-area` folder.
5. Open any object, for example <https://www.openstreetmap.org/way/966679261>.

## What it does

When the page URL selects a way or a relation, a small panel appears under the
object title showing:

- area in square metres and hectares,
- whether it is tagged as a building,
- how many inner rings (courtyards/holes) were subtracted,
- a **Copy** button that copies the area in square metres.

## How the area is calculated

The extension reads the object's geometry from OpenStreetMap's own API and
computes the area on a local tangent plane using the WGS84 ellipsoid's radii of
curvature. For real buildings this matches a full geodesic calculation to well
under 1 m². Multipolygon relations are assembled from their member ways, and
inner rings are subtracted from the outer rings so courtyards are not counted.

## Accuracy and limitations

- The result describes the **flat mapped footprint** only. It is not floor area,
  not the sum over storeys, and not an official survey.
- Accuracy is limited by how precisely the building is mapped in OpenStreetMap.
- Relations whose geometry cannot be closed into rings report that no area is
  available rather than showing a guess.
- Open ways and plain nodes have no footprint, so the panel says so.
- The extension reads data through the public OSM API. If that returns an error
  or rate-limits you, the panel shows the reason instead of a value.

## Permissions

No special permissions are requested. The script only runs on
`openstreetmap.org` and requests geometry from that same site.
